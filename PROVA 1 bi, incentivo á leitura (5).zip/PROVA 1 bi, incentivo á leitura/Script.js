const formulario = document.getElementById("meuForm");

formulario.onsubmit = function(event){

    event.preventDefault();
    

    // 3. Pega os valores dos 3 campos usando os IDs que você criou
    let emailValor = document.getElementById('email').value;
    let numeroValor = document.getElementById('number').value;
    let indexValor = document.getElementById('index').value;

    if(!(indexValor<=0||indexValor>=6)){

        // 4. Exibe os dados capturados dinamicamente na tela
    document.getElementById('resultado').innerHTML = `
       <p style="color: green;">Cadastro realizado com Sucesso!!!</p>
      
      <img class="formimg" src="certo.png">
        
    `;

    

    alert("Cadastro realizado!");





    }else{

        document.getElementById('resultado').innerHTML = `
       <p style="color: red;">Cadastro não realizado!!!</p>
       
       <img class="formimg" src="errado.png">
        
    `;

    
    alert("Cadastro não realizado!");



    }

    
};